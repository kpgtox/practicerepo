<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <title>Embed PHP in HTML</title>
    </head>
    <body>
        <h1>Embed PHP in HTML</h1>
        <p>
<?php
    echo "This is a paragraph.";
?>
        </p>
<?php
    echo "<p>This is another a paragraph.</p>";
?>
    </body>

</html>